CYBERLEARN CTF - STAGE 06
THE MISCONFIGURED SERVER

Case ID:
CL-06

Host:
ctf-linux-final

Classification:
Training Evidence Only


SCENARIO

Selected artefacts were collected from a simulated
Linux server during a security review.

Some files contain normal system information.

Other files contain information relevant to the
security investigation.


OBJECTIVE

1. Identify the Linux users.

2. Review privilege-related configuration.

3. Correlate the configuration with authentication logs.

4. Identify the security misconfiguration.

5. Follow the evidence path.

6. Recover the final CyberLearn CTF flag.


NOTE

Files originally located under /opt have been copied
into the following evidence-export directory:

filesystem/opt/
