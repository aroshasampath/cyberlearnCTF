CYBERLEARN DIGITAL FORENSICS UNIT
CASE ID: CL-DF-04

Incident Summary
----------------
A suspicious account session was detected on a training
workstation.

Your task is to examine the collected evidence and determine
what information the suspicious session accessed.

Available evidence includes:

- Authentication logs
- Web access logs
- Recent-file information
- User notes
- Cached application data

Investigators should follow the evidence trail rather than
assuming that every file is relevant.

Flag Format:
GROUP18{...}
